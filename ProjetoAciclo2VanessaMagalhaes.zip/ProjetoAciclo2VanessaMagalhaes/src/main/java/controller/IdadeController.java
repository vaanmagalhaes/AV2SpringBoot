package controller;


import dto.IdadeDTO;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/idade")
public class IdadeController {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @PostMapping("/enviaridade")
    public void enviarIdade(@RequestBody IdadeDTO idadeDTO){
        rabbitTemplate.convertAndSend("provac2VanessaMagalhaes", idadeDTO);
    }
}
