package senac.br.ProjetoAciclo2VanessaMagalhaes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoAciclo2VanessaMagalhaesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoAciclo2VanessaMagalhaesApplication.class, args);
	}

}
