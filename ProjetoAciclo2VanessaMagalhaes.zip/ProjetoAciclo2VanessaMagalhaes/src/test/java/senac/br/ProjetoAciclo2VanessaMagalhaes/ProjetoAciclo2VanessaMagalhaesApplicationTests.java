package senac.br.ProjetoAciclo2VanessaMagalhaes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoAciclo2VanessaMagalhaesApplicationTests {

	@Test
	void contextLoads() {
	}

}
