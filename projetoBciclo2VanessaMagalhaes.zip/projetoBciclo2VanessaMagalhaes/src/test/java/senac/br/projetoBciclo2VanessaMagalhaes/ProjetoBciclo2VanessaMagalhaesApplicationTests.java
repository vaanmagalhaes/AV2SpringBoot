package senac.br.projetoBciclo2VanessaMagalhaes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoBciclo2VanessaMagalhaesApplicationTests {

	@Test
	void contextLoads() {
	}

}
