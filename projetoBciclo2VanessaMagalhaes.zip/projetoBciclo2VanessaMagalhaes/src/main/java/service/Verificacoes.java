package service;

import entity.VerificadorIdade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;

public class Verificacoes {
    private static final Logger log = LoggerFactory.getLogger(Verificacoes.class);

    private VerificadorIdade event;
    String status = event.getIdade() >= 18 ? "Maior de idade" : "menor de idade";

    @RabbitListener(queues = "provac2VanessaMagalhaes")
    public void handleOrderCreated(VerificadorIdade event){
        log.info("[NOTIFICATION] Idade informada {} é {}",
                event.getIdade(),
                status);
    }
}
