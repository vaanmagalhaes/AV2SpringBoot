package senac.br.projetoBciclo2VanessaMagalhaes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoBciclo2VanessaMagalhaesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoBciclo2VanessaMagalhaesApplication.class, args);
	}

}
