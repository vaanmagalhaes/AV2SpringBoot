package config;

import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MQConfig {
    public static final String EXCHANGE_NAME = "idades.exchange";
    public static final String QUEUE_NAME = "provac2VanessaMagalhaes";
    public static final String ROUTING_KEY = "verificacoes.created";

    @Bean
    public DirectExchange idadesExchange(){
        return new DirectExchange(EXCHANGE_NAME);
    }

    @Bean
    public Queue idadesQueue(){
        return QueueBuilder.durable(QUEUE_NAME).build();
    }

    public Binding idadesBinding(Queue ordersQueue, DirectExchange ordersExchange){
        return BindingBuilder.bind(ordersQueue).to(ordersExchange).with(ROUTING_KEY);
    }
}